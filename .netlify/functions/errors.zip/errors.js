/**
 * Netlify Function: Error Reporting Endpoint
 * Captures and logs frontend errors for debugging
 */

exports.handler = async (event, context) => {
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
      },
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
      },
      body: ''
    };
  }

  try {
    const errorReport = JSON.parse(event.body);
    
    // Enhanced error logging with structured data
    const logEntry = {
      timestamp: new Date().toISOString(),
      level: 'ERROR',
      source: 'frontend-errorboundary',
      error: {
        name: errorReport.error?.name || 'Unknown',
        message: errorReport.error?.message || 'No message',
        stack: errorReport.error?.stack || 'No stack trace'
      },
      context: {
        url: errorReport.url,
        userAgent: errorReport.userAgent,
        retryCount: errorReport.retryCount,
        componentStack: errorReport.errorInfo?.componentStack || 'No component stack',
        buildInfo: errorReport.buildInfo
      }
    };

    // Log to console (visible in Netlify function logs)
    console.error('🚨 FRONTEND ERROR REPORT:', JSON.stringify(logEntry, null, 2));
    
    // Also log a simplified version for easier scanning
    console.error(`🚨 ERROR: ${errorReport.error?.name}: ${errorReport.error?.message}`);
    console.error(`📍 URL: ${errorReport.url}`);
    console.error(`🔄 Retry Count: ${errorReport.retryCount}`);
    console.error(`📱 User Agent: ${errorReport.userAgent}`);
    
    if (errorReport.error?.stack) {
      console.error('📚 Stack Trace:', errorReport.error.stack);
    }
    
    if (errorReport.errorInfo?.componentStack) {
      console.error('🧩 Component Stack:', errorReport.errorInfo.componentStack);
    }

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        success: true, 
        message: 'Error report received and logged',
        timestamp: logEntry.timestamp
      })
    };

  } catch (error) {
    console.error('Failed to process error report:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        error: 'Failed to process error report',
        details: error.message
      })
    };
  }
};
