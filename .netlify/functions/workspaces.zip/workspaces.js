const { PrismaClient } = require('@prisma/client');
const jwt = require('jsonwebtoken');

const prisma = new PrismaClient();

// Helper to handle CORS
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
};

// Helper to parse request path
const getEndpoint = (event) => {
  const path = event.path.replace('/api/workspaces', '').replace('/.netlify/functions/workspaces', '');
  return path || '/';
};

// Helper to verify user token
const verifyUserToken = (event) => {
  const authHeader = event.headers.authorization || event.headers.Authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new Error('No token provided');
  }

  const token = authHeader.replace('Bearer ', '');
  const jwtSecret = process.env.JWT_SECRET || 'dev-secret-key';
  
  try {
    const decoded = jwt.verify(token, jwtSecret);
    return decoded;
  } catch (error) {
    throw new Error('Invalid token');
  }
};

exports.handler = async (event, context) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    const endpoint = getEndpoint(event);
    const method = event.httpMethod;

    // Verify authentication for all workspace requests
    const user = verifyUserToken(event);

    // Handle different workspace endpoints
    switch (endpoint) {
      case '/':
        if (method === 'GET') {
          // Get user's workspaces
          const workspaces = await prisma.workspace.findMany({
            where: {
              members: {
                some: {
                  userId: user.id
                }
              }
            },
            include: {
              members: {
                include: {
                  user: {
                    select: {
                      id: true,
                      username: true,
                      email: true
                    }
                  }
                }
              },
              owner: {
                select: {
                  id: true,
                  username: true,
                  email: true
                }
              }
            }
          });

          return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ workspaces })
          };
        }

        if (method === 'POST') {
          // Create new workspace
          const { name, description } = JSON.parse(event.body);

          const workspace = await prisma.workspace.create({
            data: {
              name,
              description,
              ownerId: user.id,
              members: {
                create: {
                  userId: user.id,
                  role: 'OWNER'
                }
              }
            },
            include: {
              members: {
                include: {
                  user: {
                    select: {
                      id: true,
                      username: true,
                      email: true
                    }
                  }
                }
              },
              owner: {
                select: {
                  id: true,
                  username: true,
                  email: true
                }
              }
            }
          });

          return {
            statusCode: 201,
            headers: corsHeaders,
            body: JSON.stringify({ workspace })
          };
        }
        break;

      default:
        // Handle workspace-specific routes like /:id, /:id/members, etc.
        const pathParts = endpoint.split('/').filter(p => p);
        
        if (pathParts.length >= 1) {
          const workspaceId = pathParts[0];
          
          if (method === 'GET') {
            // Get specific workspace
            const workspace = await prisma.workspace.findFirst({
              where: {
                id: workspaceId,
                members: {
                  some: {
                    userId: user.id
                  }
                }
              },
              include: {
                members: {
                  include: {
                    user: {
                      select: {
                        id: true,
                        username: true,
                        email: true
                      }
                    }
                  }
                },
                owner: {
                  select: {
                    id: true,
                    username: true,
                    email: true
                  }
                }
              }
            });

            if (!workspace) {
              return {
                statusCode: 404,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Workspace not found' })
              };
            }

            return {
              statusCode: 200,
              headers: corsHeaders,
              body: JSON.stringify({ workspace })
            };
          }
        }

        return {
          statusCode: 404,
          headers: corsHeaders,
          body: JSON.stringify({ error: 'Endpoint not found' })
        };
    }

    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Method not allowed' })
    };

  } catch (error) {
    console.error('Workspaces API error:', error);

    // Handle authentication errors
    if (error.message === 'No token provided' || error.message === 'Invalid token') {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Unauthorized' })
      };
    }

    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        error: 'Internal server error',
        details: process.env.NODE_ENV === 'development' ? error.message : undefined
      })
    };
  }
};